const express = require('express');
const router = express.Router();
const uploadController = require('../controllers/uploadController');
const uploadMiddleware = require('../middleware/uploadMiddleware');

// Profile upload route
router.post('/profile', uploadMiddleware.single('profileImage'), uploadController.createProfile);

module.exports = router;
