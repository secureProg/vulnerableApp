const express = require('express');
const router = express.Router();
const ssrfController = require('../controllers/ssrfController');

// YouTube URL validation route
router.post('/validate-youtube', ssrfController.validateYouTubeUrl);

module.exports = router;
