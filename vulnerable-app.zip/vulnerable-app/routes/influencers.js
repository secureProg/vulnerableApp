const express = require('express');
const router = express.Router();
const influencerController = require('../controllers/influencerController');

// Get all influencers
router.get('/', influencerController.getAllInfluencers);

module.exports = router;
