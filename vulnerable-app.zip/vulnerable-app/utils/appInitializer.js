const fs = require('fs');
const path = require('path');

const initializeApp = () => {
    // Create uploads directory if it doesn't exist
    const uploadsDir = path.join(__dirname, '..', 'uploads');
    if (!fs.existsSync(uploadsDir)) {
        fs.mkdirSync(uploadsDir, { recursive: true });
    }

    // Create sample secret file
    const secretContent = 'FLAG{c0ngr4ts_y0u_f0und_th3_s3cr3t_f1l3}';
    const secretPath = path.join(__dirname, '..', 'secret.txt');
    fs.writeFileSync(secretPath, secretContent);
    
    // Add sample configuration
    const configContent = `# Application Configuration
DATABASE_URL=mongodb://localhost:27017/influencer_hub
JWT_SECRET=super_secret_key_12345
ADMIN_PASSWORD=admin123
API_KEY=sk-1234567890abcdef
`;
    const configPath = path.join(__dirname, '..', 'config.env');
    fs.writeFileSync(configPath, configContent);
    
    console.log('Application initialized successfully');
};

module.exports = {
    initializeApp
};
