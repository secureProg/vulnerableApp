const influencerService = require('../services/influencerService');

const createProfile = (req, res) => {
    try {
        const { influencerName, youtubeUrl, bio } = req.body;
        
        if (!influencerName || !youtubeUrl) {
            return res.status(400).json({ 
                error: 'Influencer name and YouTube URL are required' 
            });
        }

        const profileData = {
            id: Date.now(),
            name: influencerName,
            bio: bio || '',
            youtubeUrl: youtubeUrl,
            profileImage: req.file ? `/uploads/${req.file.filename}` : null,
            createdAt: new Date().toISOString()
        };

        influencerService.addInfluencer(profileData);
        res.json({ success: true, profile: profileData });
        
    } catch (error) {
        console.error('Upload error:', error);
        res.status(500).json({ error: 'Failed to create profile' });
    }
};

module.exports = {
    createProfile
};
