const fileService = require('../services/fileService');

const downloadFile = (req, res) => {
    try {
        const { file } = req.query;
        
        if (!file) {
            return res.status(400).json({ error: 'File parameter is required' });
        }

        if (file.includes('..')) {
            return res.status(400).json({ error: 'Invalid file path' });
        }

        const result = fileService.getFile(file);
        
        if (!result.exists) {
            return res.status(404).json({ error: 'File not found' });
        }

        // Send file to client
        res.download(result.path, (err) => {
            if (err) {
                console.error('Download error:', err);
                res.status(500).json({ error: 'Error downloading file' });
            }
        });
        
    } catch (error) {
        console.error('File access error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

module.exports = {
    downloadFile
};
