const influencerService = require('../services/influencerService');

const getAllInfluencers = (req, res) => {
    try {
        const influencers = influencerService.getAllInfluencers();
        res.json(influencers);
    } catch (error) {
        console.error('Error fetching influencers:', error);
        res.status(500).json({ error: 'Failed to fetch influencers' });
    }
};

module.exports = {
    getAllInfluencers
};
