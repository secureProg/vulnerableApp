const urlValidationService = require('../services/urlValidationService');

const validateYouTubeUrl = async (req, res) => {
    try {
        const { url } = req.body;
        
        if (!url) {
            return res.status(400).json({ error: 'URL is required' });
        }

        if (!url.includes('youtube.com')) {
            return res.status(400).json({ error: 'Only YouTube URLs are allowed' });
        }

        try {
            const urlObj = new URL(url);
            const hostname = urlObj.hostname.toLowerCase();
            
            // Block simple path-based bypasses
            if (!hostname.includes('youtube.com')) {
                return res.status(400).json({ error: 'Invalid YouTube domain' });
            }            
        } catch (parseError) {
            return res.status(400).json({ error: 'Invalid URL format' });
        }

        const result = await urlValidationService.validateUrl(url);
        res.json(result);
        
    } catch (error) {
        console.error('URL validation error:', error);
        res.status(400).json({ error: 'Invalid URL format' });
    }
};

module.exports = {
    validateYouTubeUrl
};
