const path = require('path');
const fs = require('fs');

const getFile = (fileName) => {
    const decodedFile = decodeURIComponent(fileName);
    const filePath = path.join(__dirname, '..', 'uploads', decodedFile);

    // Check if file exists
    const exists = fs.existsSync(filePath);
    
    return {
        exists,
        path: filePath,
        name: decodedFile
    };
};

const deleteFile = (fileName) => {
    const decodedFile = decodeURIComponent(fileName);
    const filePath = path.join(__dirname, '..', 'uploads', decodedFile);

    try {
        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
            return true;
        }
        return false;
    } catch (error) {
        console.error('Error deleting file:', error);
        return false;
    }
};

const getFileInfo = (fileName) => {
    const decodedFile = decodeURIComponent(fileName);
    const filePath = path.join(__dirname, '..', 'uploads', decodedFile);

    try {
        if (fs.existsSync(filePath)) {
            const stats = fs.statSync(filePath);
            return {
                exists: true,
                name: decodedFile,
                size: stats.size,
                created: stats.birthtime,
                modified: stats.mtime,
                path: filePath
            };
        }
        return { exists: false };
    } catch (error) {
        console.error('Error getting file info:', error);
        return { exists: false, error: error.message };
    }
};

module.exports = {
    getFile,
    deleteFile,
    getFileInfo
};
