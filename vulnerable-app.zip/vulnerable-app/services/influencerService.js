// In-memory storage for influencer profiles
let influencers = [];

const getAllInfluencers = () => {
    return influencers;
};

const addInfluencer = (profileData) => {
    influencers.push(profileData);
    return profileData;
};

const getInfluencerById = (id) => {
    return influencers.find(influencer => influencer.id === id);
};

const updateInfluencer = (id, updateData) => {
    const index = influencers.findIndex(influencer => influencer.id === id);
    if (index !== -1) {
        influencers[index] = { ...influencers[index], ...updateData };
        return influencers[index];
    }
    return null;
};

const deleteInfluencer = (id) => {
    const index = influencers.findIndex(influencer => influencer.id === id);
    if (index !== -1) {
        return influencers.splice(index, 1)[0];
    }
    return null;
};

module.exports = {
    getAllInfluencers,
    addInfluencer,
    getInfluencerById,
    updateInfluencer,
    deleteInfluencer
};
