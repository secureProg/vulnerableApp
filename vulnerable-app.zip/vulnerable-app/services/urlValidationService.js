const https = require('https');
const http = require('http');
const { URL } = require('url');

const validateUrl = async (url) => {
    return new Promise((resolve, reject) => {
        try {
            const urlObj = new URL(url);
            const protocol = urlObj.protocol === 'https:' ? https : http;
            
            const options = {
                hostname: urlObj.hostname,
                port: urlObj.port || (urlObj.protocol === 'https:' ? 443 : 80),
                path: urlObj.pathname + urlObj.search,
                method: 'GET',
                timeout: 5000
            };

            const request = protocol.request(options, (response) => {
                let data = '';
                response.on('data', (chunk) => {
                    data += chunk;
                });
                response.on('end', () => {
                    resolve({ 
                        valid: true, 
                        message: 'YouTube URL is valid',
                        status: response.statusCode,
                        preview: data.substring(0, 200) + '...'
                    });
                });
            });

            request.on('error', (error) => {
                reject(new Error('Failed to validate URL: ' + error.message));
            });

            request.on('timeout', () => {
                request.destroy();
                reject(new Error('Request timeout'));
            });

            request.end();
        } catch (error) {
            reject(error);
        }
    });
};

module.exports = {
    validateUrl
};
