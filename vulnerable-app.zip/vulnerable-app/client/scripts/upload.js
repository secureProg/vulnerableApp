// Upload page functionality

document.addEventListener('DOMContentLoaded', function() {
    const uploadForm = document.getElementById('uploadForm');
    
    if (uploadForm) {
        uploadForm.addEventListener('submit', handleFormSubmission);
    }
});

// Handle form submission
async function handleFormSubmission(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    showLoading(true);
    
    try {
        const response = await fetch('/api/upload/profile', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
            showAlert('Profile created successfully! Welcome to the network!', 'success');
            e.target.reset();
            
            // Redirect to home page after successful upload
            setTimeout(() => {
                window.location.href = '/';
            }, 2000);
        } else {
            showAlert(result.error || 'Failed to create profile. Please try again.', 'error');
        }
    } catch (error) {
        console.error('Upload error:', error);
        showAlert('Network error: ' + error.message, 'error');
    } finally {
        showLoading(false);
    }
}

// YouTube URL validation function
async function validateYouTubeUrl() {
    const urlInput = document.getElementById('youtubeUrl');
    const url = urlInput.value.trim();
    
    if (!url) {
        showAlert('Please enter a YouTube URL first', 'error');
        urlInput.focus();
        return;
    }

    showLoading(true);
    
    try {
        const result = await API.post('/api/ssrf/validate-youtube', { url: url });
        
        if (result.valid) {
            showAlert('YouTube URL validated successfully!', 'success');
        } else {
            showAlert(result.error || 'Invalid YouTube URL format', 'error');
        }
    } catch (error) {
        console.error('Validation error:', error);
        showAlert('Validation error: ' + error.message, 'error');
    } finally {
        showLoading(false);
    }
}

// File upload preview
document.addEventListener('DOMContentLoaded', function() {
    const fileInput = document.getElementById('profileImage');
    
    if (fileInput) {
        fileInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                // Validate file size
                if (file.size > 5 * 1024 * 1024) {
                    showAlert('File size must be less than 5MB', 'error');
                    this.value = '';
                    return;
                }
                
                // Show file info
                const fileInfo = document.querySelector('.file-info');
                if (fileInfo) {
                    fileInfo.textContent = `Selected: ${file.name} (${formatFileSize(file.size)})`;
                }
                
                // Preview image if it's an image file
                if (file.type.startsWith('image/')) {
                    previewImage(file);
                }
            }
        });
    }
});

// Preview image function
function previewImage(file) {
    const reader = new FileReader();
    reader.onload = function(e) {
        // Remove existing preview
        const existingPreview = document.getElementById('imagePreview');
        if (existingPreview) {
            existingPreview.remove();
        }
        
        // Create new preview
        const preview = document.createElement('div');
        preview.id = 'imagePreview';
        preview.style.marginTop = '10px';
        preview.innerHTML = `
            <img src="${e.target.result}" style="max-width: 200px; max-height: 200px; border-radius: 8px; border: 2px solid #e1e5e9;" alt="Preview">
            <p style="font-size: 12px; color: #6c757d; margin-top: 5px;">Preview of selected image</p>
        `;
        
        // Insert after file input
        const fileInput = document.getElementById('profileImage');
        fileInput.parentNode.insertBefore(preview, fileInput.nextSibling);
    };
    reader.readAsDataURL(file);
}
