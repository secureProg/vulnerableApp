// Download page functionality

document.addEventListener('DOMContentLoaded', function() {
    const downloadForm = document.getElementById('downloadForm');
    
    if (downloadForm) {
        downloadForm.addEventListener('submit', handleFileDownload);
    }
});

// Handle file download
async function handleFileDownload(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const fileName = formData.get('fileName');
    
    if (!fileName) {
        showAlert('Please enter a filename', 'error');
        return;
    }
    
    showLoading(true);
    hideFileInfo();
    
    try {
        // Create download URL
        const downloadUrl = `/api/download?file=${encodeURIComponent(fileName)}`;
        
        // Attempt to download the file
        const response = await fetch(downloadUrl);
        
        if (response.ok) {
            // Get filename from response headers or use provided name
            const contentDisposition = response.headers.get('Content-Disposition');
            let downloadFileName = fileName;
            
            if (contentDisposition) {
                const filenameMatch = contentDisposition.match(/filename="(.+)"/);
                if (filenameMatch) {
                    downloadFileName = filenameMatch[1];
                }
            }
            
            // Create blob and download
            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = downloadFileName;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
            
            showAlert(`File "${downloadFileName}" downloaded successfully!`, 'success');
            
            // Show file info
            displayFileInfo({
                name: downloadFileName,
                size: blob.size,
                type: blob.type || 'Unknown',
                downloaded: true
            });
            
        } else {
            const errorData = await response.json();
            showAlert(errorData.error || 'File not found', 'error');
        }
        
    } catch (error) {
        console.error('Download error:', error);
        showAlert('Download error: ' + error.message, 'error');
    } finally {
        showLoading(false);
    }
}

// Display file information
function displayFileInfo(fileInfo) {
    const fileInfoContainer = document.getElementById('fileInfo');
    const fileInfoContent = document.getElementById('fileInfoContent');
    
    if (!fileInfoContainer || !fileInfoContent) return;
    
    fileInfoContent.innerHTML = `
        <div class="file-info-item">
            <strong>Filename:</strong> ${escapeHtml(fileInfo.name)}
        </div>
        <div class="file-info-item">
            <strong>Size:</strong> ${formatFileSize(fileInfo.size)}
        </div>
        <div class="file-info-item">
            <strong>Type:</strong> ${escapeHtml(fileInfo.type)}
        </div>
        <div class="file-info-item">
            <strong>Status:</strong> ${fileInfo.downloaded ? '✅ Downloaded' : '❌ Failed'}
        </div>
        ${fileInfo.downloaded ? `
        <div class="file-info-item">
            <strong>Downloaded at:</strong> ${formatDate(new Date())}
        </div>
        ` : ''}
    `;
    
    fileInfoContainer.style.display = 'block';
}

// Hide file info
function hideFileInfo() {
    const fileInfoContainer = document.getElementById('fileInfo');
    if (fileInfoContainer) {
        fileInfoContainer.style.display = 'none';
    }
}

// Clear form and info
function clearForm() {
    const form = document.getElementById('downloadForm');
    if (form) {
        form.reset();
    }
    hideFileInfo();
}

// Quick download function
function downloadQuickFile(fileName) {
    const fileNameInput = document.getElementById('fileName');
    if (fileNameInput) {
        fileNameInput.value = fileName;
        
        // Trigger download
        const form = document.getElementById('downloadForm');
        if (form) {
            const event = new Event('submit', {
                bubbles: true,
                cancelable: true
            });
            form.dispatchEvent(event);
        }
    }
}

// Show uploaded files (demo function)
async function showUploadedFiles() {
    try {
        showLoading(true);
        
        // This is a demo function - in a real app you'd have an API endpoint
        // that lists uploaded files
        const commonFiles = [
            'secret.txt',
            'config.env',
            'sample-image.jpg',
            'profile-123456.png',
            'document.pdf'
        ];
        
        const fileList = commonFiles.map(file => `
            <button type="button" class="btn btn-small" onclick="downloadQuickFile('${file}')">${file}</button>
        `).join('');
        
        // Show files in an alert-like container
        const alertContainer = document.getElementById('alertContainer');
        if (alertContainer) {
            const fileListDiv = document.createElement('div');
            fileListDiv.className = 'alert alert-success';
            fileListDiv.innerHTML = `
                <strong>Recent Files:</strong><br>
                <div style="margin-top: 10px;">
                    ${fileList}
                </div>
            `;
            alertContainer.appendChild(fileListDiv);
            
            setTimeout(() => {
                if (fileListDiv.parentNode) {
                    fileListDiv.remove();
                }
            }, 10000);
        }
        
    } catch (error) {
        console.error('Error showing files:', error);
        showAlert('Error loading file list', 'error');
    } finally {
        showLoading(false);
    }
}

// Add CSS for file info items
const style = document.createElement('style');
style.textContent = `
    .file-info-item {
        margin-bottom: 8px;
        padding: 6px;
        border-left: 3px solid #28a745;
        background: white;
        border-radius: 4px;
        font-size: 14px;
    }
    
    .file-info-item strong {
        color: #28a745;
        margin-right: 8px;
    }
`;
document.head.appendChild(style);
