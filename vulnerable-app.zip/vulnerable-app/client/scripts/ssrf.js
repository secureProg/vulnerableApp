// SSRF page functionality

document.addEventListener('DOMContentLoaded', function() {
    const urlValidationForm = document.getElementById('urlValidationForm');
    
    if (urlValidationForm) {
        urlValidationForm.addEventListener('submit', handleUrlValidation);
    }
});

// Handle URL validation
async function handleUrlValidation(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const url = formData.get('youtubeUrl');
    
    if (!url) {
        showAlert('Please enter a YouTube URL', 'error');
        return;
    }
    
    showLoading(true);
    hideResults();
    
    try {
        const result = await API.post('/api/ssrf/validate-youtube', { url: url });
        
        if (result.valid) {
            showAlert('URL validation successful!', 'success');
            displayResults(result);
        } else {
            showAlert(result.error || 'URL validation failed', 'error');
        }
    } catch (error) {
        console.error('Validation error:', error);
        showAlert('Validation error: ' + error.message, 'error');
    } finally {
        showLoading(false);
    }
}

// Display validation results
function displayResults(result) {
    const resultsContainer = document.getElementById('validationResults');
    const resultsContent = document.getElementById('resultsContent');
    
    if (!resultsContainer || !resultsContent) return;
    
    resultsContent.innerHTML = `
        <div class="result-item">
            <strong>Status:</strong> ${result.valid ? 'Valid' : 'Invalid'}
        </div>
        <div class="result-item">
            <strong>HTTP Status:</strong> ${result.status || 'N/A'}
        </div>
        <div class="result-item">
            <strong>Message:</strong> ${escapeHtml(result.message || 'No message')}
        </div>
        ${result.preview ? `
        <div class="result-item">
            <strong>Preview:</strong>
            <div style="background: #f8f9fa; padding: 10px; border-radius: 4px; margin-top: 5px; font-family: monospace; font-size: 12px; word-break: break-all;">
                ${escapeHtml(result.preview)}
            </div>
        </div>
        ` : ''}
    `;
    
    resultsContainer.style.display = 'block';
}

// Hide results
function hideResults() {
    const resultsContainer = document.getElementById('validationResults');
    if (resultsContainer) {
        resultsContainer.style.display = 'none';
    }
}

// Clear form and results
function clearForm() {
    const form = document.getElementById('urlValidationForm');
    if (form) {
        form.reset();
    }
    hideResults();
}

// Quick test functions for common URLs
function testCommonUrls() {
    const testUrls = [
        'https://youtube.com/watch?v=dQw4w9WgXcQ',
        'https://youtube.com@localhost:3000/api/influencers',
        'https://youtube.com@127.0.0.1:3000/api/download?file=secret.txt'
    ];
    
    const urlInput = document.getElementById('youtubeUrl');
    if (urlInput && testUrls.length > 0) {
        urlInput.value = testUrls[Math.floor(Math.random() * testUrls.length)];
    }
}

// Add some example URLs for testing
document.addEventListener('DOMContentLoaded', function() {
    const urlInput = document.getElementById('youtubeUrl');
    
    if (urlInput) {
        // Add placeholder with example
        urlInput.setAttribute('placeholder', 'https://youtube.com/channel/your-channel');
        
        // Add example button (for testing purposes)
        const exampleButton = document.createElement('button');
        exampleButton.type = 'button';
        exampleButton.className = 'btn btn-small';
        exampleButton.textContent = 'Use Example';
        exampleButton.style.marginTop = '10px';
        exampleButton.onclick = function() {
            urlInput.value = 'https://youtube.com/watch?v=dQw4w9WgXcQ';
        };
        
        // Insert after the input
        urlInput.parentNode.insertBefore(exampleButton, urlInput.nextSibling);
    }
});

// Add CSS for result items
const style = document.createElement('style');
style.textContent = `
    .result-item {
        margin-bottom: 10px;
        padding: 8px;
        border-left: 3px solid #667eea;
        background: white;
        border-radius: 4px;
    }
    
    .result-item strong {
        color: #667eea;
        margin-right: 8px;
    }
`;
document.head.appendChild(style);
