// Influencers display functionality

document.addEventListener('DOMContentLoaded', function() {
    // Only load influencers on the main page
    if (document.getElementById('influencersGrid')) {
        loadInfluencers();
    }
});

// Load and display influencers
async function loadInfluencers() {
    try {
        const influencers = await API.get('/api/influencers');
        displayInfluencers(influencers);
    } catch (error) {
        console.error('Error loading influencers:', error);
        showInfluencersError();
    }
}

// Display influencers in the grid
function displayInfluencers(influencers) {
    const grid = document.getElementById('influencersGrid');
    if (!grid) return;
    
    grid.innerHTML = '';
    
    if (influencers.length === 0) {
        grid.innerHTML = `
            <div style="text-align: center; color: #6c757d; grid-column: 1 / -1; padding: 40px;">
                <h3>No influencers yet</h3>
                <p>Be the first to create your profile and join our community!</p>
                <a href="upload.html" class="btn" style="margin-top: 15px;">Create Profile</a>
            </div>
        `;
        return;
    }
    
    influencers.forEach(influencer => {
        const card = createInfluencerCard(influencer);
        grid.appendChild(card);
    });
}

// Create individual influencer card
function createInfluencerCard(influencer) {
    const card = document.createElement('div');
    card.className = 'influencer-card';
    
    const imageHtml = influencer.profileImage 
        ? `<img src="${influencer.profileImage}" alt="Profile" class="profile-image" onerror="this.outerHTML='<div class=\\'profile-placeholder\\'>Image not available</div>'">`
        : '<div class="profile-placeholder">No Image Uploaded</div>';
    
    const createdDate = influencer.createdAt ? formatDate(influencer.createdAt) : 'Unknown';
    
    card.innerHTML = `
        <div class="influencer-name">${escapeHtml(influencer.name)}</div>
        ${imageHtml}
        <div class="influencer-bio">${escapeHtml(influencer.bio || 'No bio available')}</div>
        <div class="influencer-meta">
            <small style="color: #6c757d;">Joined: ${createdDate}</small>
        </div>
        <div class="influencer-actions">
            <a href="${escapeHtml(influencer.youtubeUrl)}" target="_blank" rel="noopener noreferrer" class="youtube-link">
                Visit Channel
            </a>
        </div>
    `;
    
    // Add click event for card interaction
    card.addEventListener('click', function(e) {
        // Don't trigger if clicking on links
        if (e.target.tagName === 'A') return;
        
        showInfluencerDetails(influencer);
    });
    
    return card;
}

// Show influencer details in a modal-like display
function showInfluencerDetails(influencer) {
    const alertContainer = document.getElementById('alertContainer');
    if (!alertContainer) return;
    
    // Remove existing details if any
    const existingDetails = document.getElementById('influencerDetails');
    if (existingDetails) {
        existingDetails.remove();
    }
    
    const detailsDiv = document.createElement('div');
    detailsDiv.id = 'influencerDetails';
    detailsDiv.className = 'card';
    detailsDiv.style.position = 'fixed';
    detailsDiv.style.top = '50%';
    detailsDiv.style.left = '50%';
    detailsDiv.style.transform = 'translate(-50%, -50%)';
    detailsDiv.style.zIndex = '1000';
    detailsDiv.style.maxWidth = '500px';
    detailsDiv.style.maxHeight = '80vh';
    detailsDiv.style.overflow = 'auto';
    
    detailsDiv.innerHTML = `
        <div style="display: flex; justify-content: between; align-items: center; margin-bottom: 20px;">
            <h3>Influencer Details</h3>
            <button onclick="closeInfluencerDetails()" style="background: none; border: none; font-size: 24px; cursor: pointer; float: right;">&times;</button>
        </div>
        <div><strong>Name:</strong> ${escapeHtml(influencer.name)}</div>
        <div style="margin-top: 10px;"><strong>Bio:</strong> ${escapeHtml(influencer.bio || 'No bio provided')}</div>
        <div style="margin-top: 10px;"><strong>YouTube:</strong> <a href="${escapeHtml(influencer.youtubeUrl)}" target="_blank">${escapeHtml(influencer.youtubeUrl)}</a></div>
        <div style="margin-top: 10px;"><strong>Joined:</strong> ${influencer.createdAt ? formatDate(influencer.createdAt) : 'Unknown'}</div>
        ${influencer.profileImage ? `<div style="margin-top: 15px;"><img src="${influencer.profileImage}" alt="Profile" style="max-width: 100%; border-radius: 8px;"></div>` : ''}
    `;
    
    // Add backdrop
    const backdrop = document.createElement('div');
    backdrop.id = 'modalBackdrop';
    backdrop.style.position = 'fixed';
    backdrop.style.top = '0';
    backdrop.style.left = '0';
    backdrop.style.width = '100%';
    backdrop.style.height = '100%';
    backdrop.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
    backdrop.style.zIndex = '999';
    backdrop.onclick = closeInfluencerDetails;
    
    document.body.appendChild(backdrop);
    document.body.appendChild(detailsDiv);
}

// Close influencer details modal
function closeInfluencerDetails() {
    const details = document.getElementById('influencerDetails');
    const backdrop = document.getElementById('modalBackdrop');
    
    if (details) details.remove();
    if (backdrop) backdrop.remove();
}

// Show error when loading influencers fails
function showInfluencersError() {
    const grid = document.getElementById('influencersGrid');
    if (!grid) return;
    
    grid.innerHTML = `
        <div style="text-align: center; color: #721c24; grid-column: 1 / -1; padding: 40px;">
            <h3>Error Loading Influencers</h3>
            <p>Failed to load influencer profiles. Please refresh the page to try again.</p>
            <button onclick="loadInfluencers()" class="btn" style="margin-top: 15px;">Retry</button>
        </div>
    `;
}

// Refresh influencers (useful after creating a new profile)
function refreshInfluencers() {
    const grid = document.getElementById('influencersGrid');
    if (grid) {
        grid.innerHTML = '<div style="text-align: center; padding: 40px;">Loading...</div>';
        loadInfluencers();
    }
}

// Search/filter influencers (basic implementation)
function filterInfluencers(searchTerm) {
    const cards = document.querySelectorAll('.influencer-card');
    const term = searchTerm.toLowerCase();
    
    cards.forEach(card => {
        const name = card.querySelector('.influencer-name')?.textContent.toLowerCase() || '';
        const bio = card.querySelector('.influencer-bio')?.textContent.toLowerCase() || '';
        
        if (name.includes(term) || bio.includes(term)) {
            card.style.display = 'block';
        } else {
            card.style.display = 'none';
        }
    });
}

// Make functions globally available
window.closeInfluencerDetails = closeInfluencerDetails;
window.refreshInfluencers = refreshInfluencers;
window.filterInfluencers = filterInfluencers;
