const express = require('express');
const path = require('path');
const { initializeApp } = require('./utils/appInitializer');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware setup
app.use(express.static('client'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Static file serving for uploads
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Import routes
const uploadRoutes = require('./routes/upload');
const ssrfRoutes = require('./routes/ssrf');
const downloadRoutes = require('./routes/download');
const influencerRoutes = require('./routes/influencers');

// Use routes
app.use('/api/upload', uploadRoutes);
app.use('/api/ssrf', ssrfRoutes);
app.use('/api/download', downloadRoutes);
app.use('/api/influencers', influencerRoutes);

// Main page route
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'client', 'index.html'));
});

// Initialize application
initializeApp();

app.listen(PORT, '0.0.0.0', () => {
    console.log(`Influencer Network Hub running on http://0.0.0.0:${PORT}`);
    console.log('Ready to accept connections...');
});
